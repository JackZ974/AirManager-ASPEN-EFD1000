--**************************************--
------------------------------------------
-- Aspen EFD1000 Bezel gauge		    --
-- To be used with EFD1000 PFD gauge V2.0   --
-- (Intercommunication process)         --
-- VERSION 1.00 beta        02/03/16    --
-- J.ZAHAR             					--
------------------------------------------
--**************************************--
img_bezel=img_add("bezel4.png",0,0,918,1810)
---------------------
-- lateral buttons --
---------------------
var_latbuttonrevstate=am_variable_create("am_latbuttonrevstate","INT",0)
function buttonlatrevin(test)
am_variable_write(var_latbuttonrevstate,1)
end
function buttonlatrevout(test)
am_variable_write(var_latbuttonrevstate,0)
end
button_latrev=button_add("revbutton_out.png","revbutton_in.png",845,214,52,89,buttonlatrevin,buttonlatrevout)--
---------------------
var_latbuttonrangeplusstate=am_variable_create("am_latbuttonrangeplusstate","INT",0)
function buttonlatrangeplusin(test)
am_variable_write(var_latbuttonrangeplusstate,1)
end
function buttonlatrangeplusout(test)
am_variable_write(var_latbuttonrangeplusstate,0)
end
button_latplus=button_add("plusbutton_out2.png","plusbutton_in2.png",847,390,48,100,buttonlatrangeplusin,buttonlatrangeplusout)--
---------------------
var_latbuttonrangeminusstate=am_variable_create("am_latbuttonrangeminusstate","INT",0)
function buttonlatrangeminusin(test)
am_variable_write(var_latbuttonrangeminusstate,1)
end
function buttonlatrangeminusout(test)
am_variable_write(var_latbuttonrangeminusstate,0)
end
button_latminus=button_add("minusbutton_out2.png","minusbutton_in2.png",847,490,48,100,buttonlatrangeminusin,buttonlatrangeminusout)--
---------------------
var_latbuttonmenustate=am_variable_create("am_latbuttonmenustate","INT",0)
function buttonlatmenuin(test)
--if test==true then 
am_variable_write(var_latbuttonmenustate,1)
--print(latbuttonmenustate)
--end
end
function buttonlatmenuout(test)
--if test==true then 
am_variable_write(var_latbuttonmenustate,0)
--print(latbuttonmenustate)
--end
end
button_latmenu=button_add("menubutton_out.png","menubutton_in.png",848,675,50,126,buttonlatmenuin,buttonlatmenuout)--
----------------
var_latbutton1state=am_variable_create("am_latbutton1state","INT",0)
function buttonlat1in(test)
--if test==true then 
am_variable_write(var_latbutton1state,1)
--print(latbutton1state)
--end
end
function buttonlat1out(test)
--if test==true then 
am_variable_write(var_latbutton1state,0)
--print(latbutton1state)
--end
end
button_lat1=button_add("boutonlateral_out.png","boutonlateral_in2.png",850,840,48,85,buttonlat1in,buttonlat1out)--
-----------------
var_latbutton2state=am_variable_create("am_latbutton2state","INT",0)
function buttonlat2in(test)
--if test==true then 
am_variable_write(var_latbutton2state,1)
--print(latbutton2state)
--end
end
function buttonlat2out(test)
--if test==true then 
am_variable_write(var_latbutton2state,0)
--print(latbutton2state)
--end
end
button_lat2=button_add("boutonlateral_out.png","boutonlateral_in2.png",850,963,48,85,buttonlat2in,buttonlat2out)--
-----------------
var_latbutton3state=am_variable_create("am_latbutton3state","INT",0)
function buttonlat3in(test)
--if test==true then 
am_variable_write(var_latbutton3state,1)
--print(latbutton3state)
--end
end
function buttonlat3out(test)
--if test==true then 
am_variable_write(var_latbutton3state,0)
--print(latbutton3state)
--end
end
button_lat3=button_add("boutonlateral_out.png","boutonlateral_in2.png",850,1095,48,85,buttonlat3in,buttonlat3out)--
--------------
var_latbutton4state=am_variable_create("am_latbutton4state","INT",0)
function buttonlat4in(test)
--if test==true then 
am_variable_write(var_latbutton4state,1)
--print(latbutton4state)
--end
end
function buttonlat4out(test)
--if test==true then 
am_variable_write(var_latbutton4state,0)
--print(latbutton4state)
--end
end
button_lat4=button_add("boutonlateral_out.png","boutonlateral_in2.png",850,1227,48,85,buttonlat4in,buttonlat4out)--
------------

function buttonlat5in(test)
--if test==true then 
am_variable_write(var_latbutton5state,1)
--print(latbutton5state)
--end
end
function buttonlat5out(test)
--if test==true then 
am_variable_write(var_latbutton5state,0)
--print(latbutton5state)
--end
end
var_latbutton5state=am_variable_create("am_latbutton5state","INT",0)
button_lat5=button_add("boutonlateral_out.png","boutonlateral_in2.png",849,1352,48,85,buttonlat5in,buttonlat5out)--
--------------------
-- Bottom buttons --
--------------------


function srcbuttonleft(test)
leftbuttonstate=leftbuttonstate+1
if leftbuttonstate>3 then 
	leftbuttonstate=1 
	end
am_variable_write(var_leftbuttonstate,leftbuttonstate)
end
button_sourceleft=button_add("bottomleftbutton_out.png","bottomleftbutton_in.png",242,1615,145,87,srcbuttonleft,nil)--
var_leftbuttonstate=am_variable_create("am_leftbuttonstate","INT",0)
leftbuttonstate=0 --0=No display 1=GPS mode, 2=VLOC1 mode, 2=VLOC2 mode

function srcbuttoncenter(test)
centerbuttonstate=centerbuttonstate+1
if centerbuttonstate>3 then 
	centerbuttonstate=1 
	end
am_variable_write(var_centerbuttonstate,centerbuttonstate)
end
button_sourcecenter=button_add("bottombuttoncenter_out.png","bottombuttoncenter_in2.png",370,1617,184,85,srcbuttoncenter,nil)--
var_centerbuttonstate=am_variable_create("am_centerbuttonstate","INT",2)
centerbuttonstate=1 -- 1=GPS mode, 2=VLOC1 mode, 2=VLOC2 mode

function srcbuttonright(test)
rightbuttonstate=rightbuttonstate+1
if rightbuttonstate>3 then 
	rightbuttonstate=1 
	end
am_variable_write(var_rightbuttonstate,rightbuttonstate)
end
button_sourceright=button_add("bottomrightbutton_out.png","bottomrightbutton_in2.png",538,1615,146,87,srcbuttonright,nil)--
var_rightbuttonstate=am_variable_create("am_rightbuttonstate","INT",0)
rightbuttonstate=0 --0=No display 1=GPS mode, 2=VLOC1 mode, 2=VLOC2 mode
----------------------
-- Dials  functions --
----------------------
function new_obs(obsset)

	if obsset == -1 then
		xpl_command("sim/radios/obs1_down")
		fsx_event("VOR1_OBI_DEC")
	elseif obsset == 1 then
		xpl_command("sim/radios/obs1_up")
		fsx_event("VOR1_OBI_INC")
	end
	
end

function new_heading(headingset)

	if headingset == -1 then
		xpl_command("sim/autopilot/heading_down")
		fsx_event("HEADING_BUG_DEC")
	elseif headingset == 1 then
		xpl_command("sim/autopilot/heading_up")
		fsx_event("HEADING_BUG_INC")
	end
	
end
dial_OBS = dial_add("dial.png", 69, 1628, 168, 168, new_obs)
dial_BUG = dial_add("dial.png", 698, 1627, 168, 168, new_heading)
dial_click_rotate(dial_OBS, 5) -- incréments
dial_click_rotate(dial_BUG, 5)

var_dialbuttonleftstate=am_variable_create("am_dialbuttonleftstate","INT",0)
function dialleftbuttonin(test)
am_variable_write(var_dialbuttonleftstate,1)
end
function dialleftbuttonout(test)
am_variable_write(var_dialbuttonleftstate,0)
end
button_latrev=button_add(nil,nil,100,1660,105,105,dialleftbuttonin,dialleftbuttonout)--
-------------------------------------------------------
var_dialbuttonrightstate=am_variable_create("am_dialbuttonrightstate","INT",0)
function dialrightbuttonin(test)
am_variable_write(var_dialbuttonrightstate,1)
end
function dialrightbuttonout(test)
am_variable_write(var_dialbuttonrightstate,0)
end
button_latrev=button_add(nil,nil,730,1660,105,105,dialrightbuttonin,dialrightbuttonout)--
-------------------------------------------------------